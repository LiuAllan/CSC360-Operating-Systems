/*
Allan Liu
V00806981
Assignment 1 - creating a shell

Modified version of https://brennan.io/2015/01/16/write-a-shell-in-c/ provided by Dr. Yvonne.

*/
#define _GNU_SOURCE

#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>

#define KSH_RL_BUFSIZE 1024
#define KSH_TOK_BUFSIZE 64
#define KSH_TOK_DELIM " \t\r\n\a"
#define CONFIG ".kapishrc"
#define HOME getenv("HOME")

/* Built-in shell command Function Prototypes*/
int ksh_cd(char **args);
int ksh_exit(char **args);
int ksh_setenv(char **args);
int ksh_unsetenv(char **args);
void ksh_loop(void);
void handle_signal(int sig);
void child_handler(int sig);
int ksh_launch(char **args);
int ksh_execute(char **args);
char **ksh_split_line(char *line);
char *ksh_read_line(void);
void init_config();

/*wrapper function that calls malloc if allocation fails. Reports error and exits. From SENG265 Summer slides 30 - Dr. Zastre */
void *emalloc(size_t n)
{
	void *p;
	p = malloc(n);
	if (p == NULL) {
		fprintf(stderr, "ksh: malloc of %zu bytes failed\n", n);
		exit(1);
	}
	return p;
}

void handle_signal(int sig)
{
	printf("\n");
	ksh_loop();
}

void child_handler(int sig)
{
	printf("\n");
}

/*array of built-in names*/
char *built_in_str[] =
{
	"cd",
	"setenv",
	"unsetenv",
	"exit"
};

int ksh_num_builtins() 
{
  return sizeof(built_in_str) / sizeof(char *);
}

/*array of built in functions*/
int (*built_in_func[])(char **) =
{
	&ksh_cd,
	&ksh_setenv,
	&ksh_unsetenv,
	&ksh_exit
};
/*Built-in command: set environment variable*/
int ksh_setenv(char **args)
{
	if (args[1] == NULL)
	{
		fprintf(stderr, "ERROR: ksh - no environment variable\n");
	}
	/*No variable was given*/
	else if (args[2] == NULL)
	{
		setenv(args[1], "", 1);
		printf("%s=%s\n", args[1], getenv(args[1]));
	}
	else
	{
		setenv(args[1], args[2], 1);
		printf("%s=%s\n", args[1], getenv(args[1]));
	}
	return 1;
	
}
/*Built-in command: unset environment variable*/
int ksh_unsetenv(char **args)
{
	if (args[1] == NULL)
	{
		fprintf(stderr, "ERROR: ksh - no environment variable to remove\n");
	}
	else
	{
		unsetenv(args[1]);
		printf("ksh: removed env variable \'%s\'\n", args[1]);

	}
	return 1;
}

/*Built-in command: change directory*/
int ksh_cd(char **args)
{
	/*check that the a pathname exists*/
	if (args[1] == NULL)
	{
		fprintf(stderr, "ksh: expected argument to \"cd\"\n");
	}
	else
	{
		if (chdir(args[1]) != 0)
		{
			perror("ksh");
		}
	}
	return 1;
}

int ksh_exit(char **args)
{
	printf("\n");
	exit(0);
}

/*Launches a process*/
int ksh_launch(char **args)
{
	/*SIGNAL HANDLER*/
	signal(SIGINT, handle_signal);
	
	pid_t pid;
	int status;
	
	/*make a copy of the parent and returns*/
	pid = fork();
	/*fork returns the status of the child (pid ==0).*/
	if (pid == 0)
	{
		if (execvp(args[0], args) == -1)
		{
			perror("ksh");
		}
		exit(EXIT_FAILURE);
	}
	else if (pid < 0)
	{
		perror("ERROR: ksh - problem with forking\n");
	}
	else
	{
		/*run the parent process*/
		do
		{
			/*terminate*/
			signal(SIGINT, child_handler);
			
			/*child is running so the parent needs to wait for state change*/
			waitpid(pid, &status, WUNTRACED);
		}
		while (!WIFEXITED(status) && !WIFSIGNALED(status));
		
		signal(SIGINT, handle_signal);
	}
	return 1;
}

/*Function that will either launch a built-in or a process*/
int ksh_execute(char **args)
{
	int i;
	
	/*no command was given*/
	if (args[0] == NULL)
	{
		printf("ERROR: no command given\n");
		return 1;
	}
	
	for (i = 0; i < ksh_num_builtins(); i++)
	{
		/*compares if the command given is the same as the built-in command*/
		if (strcmp(args[0], built_in_str[i]) == 0)
		{
			return (*built_in_func[i])(args);
		}
	}
	/*launches a process instead*/
	return ksh_launch(args);
}
/*Function splits each line and returns the line of arguments*/
char **ksh_split_line(char *line)
{
	int buffersize = KSH_TOK_BUFSIZE;
	int position = 0;
	char **tokens = emalloc(sizeof(char*)*buffersize);
	char *token;

	/*tokenize 1 word separated by delimiters*/
	token = strtok(line, KSH_TOK_DELIM);
	while (token != NULL)
	{
		tokens[position] = token;
		position++;
		
		if (position >= buffersize)
		{
			buffersize += KSH_TOK_BUFSIZE;
			tokens = realloc(tokens, sizeof(char*)*buffersize);
			if(!tokens)
			{
				fprintf(stderr, "ERROR: ksh - failed to allocate memory\n");
				exit(EXIT_FAILURE);
			}
		}
		token = strtok(NULL, KSH_TOK_DELIM);
	}
	/*end the string with NULL char*/
	tokens[position] = NULL;
	return tokens;
}

/*Read line from stdin. Dynamically allocate memory if needed more than 1 block.*/
char *ksh_read_line(void)
{
	int buffersize = KSH_RL_BUFSIZE;
	int position = 0;
	/*emalloc allocates memory and catches exceptions*/
	char *buffer = emalloc(sizeof(char)*buffersize);
	int temp_c;
	
	for(;;)
	{
		/*Read a single character. Store as an int because EOF is an int*/
		temp_c = getchar();
		
		/*Read character by character until it reaches the end of file or new line.
		Cap off the last character with NULL and return*/
		if (temp_c == EOF || temp_c == '\n')
		{
			buffer[position] = '\0';
			
			/*Closes kapish if user commanded ^D (control + D) or exit. Otherwise, it will not close*/
			if (temp_c == EOF)
			{
				ksh_exit(NULL);
			}
			return buffer;
		}
		/*Add the character to our existing string*/
		else
		{
				buffer[position] = temp_c;
		}
		position++;
		
		/*If the character exceeds our block of memory, reallocate another block*/
		if (position >= buffersize)
		{
			buffersize += KSH_RL_BUFSIZE;
			buffer = realloc(buffer, buffersize);
			if(!buffer)
			{
				fprintf(stderr, "ERROR: ksh - failed to allocate memory\n");
				exit(EXIT_FAILURE);
			}
		}
	}
}

/*Function that continuously read arguments and execute valid commands*/
void ksh_loop(void)
{
	char *line;
	char **args;
	int status;
	
	do
	{
			printf("? ");

			/*call function to read the line*/
			line = ksh_read_line();
			
			/*split the line into arguments*/
			args = ksh_split_line(line);
			
			/*execute arguments*/
			status = ksh_execute(args);
			
			free(line);
			free(args);
	}
	while(status);
	
}
/*Function that initilizes the .kapishrc file in the user's home directory*/
void init_config()
{
	int config_len = strlen(CONFIG);
	int length = strlen(HOME) + config_len + 2;
	char *file = emalloc(sizeof(char) * length);
	
	/*path to the config file*/
	strncpy(file, HOME, length-2);
	strncat(file, "/", length-2);
	strncat(file, CONFIG, config_len);
	
	/*end with null char*/
	file[length-1] = '\0';
	
	FILE *file_pointer = fopen(file, "r");
	if(file_pointer == NULL)
	{
		printf("ERROR: ksh - Can't find .kapishrc file in home directory");
		return;
	}
	
	char *temp_line = NULL;
	size_t len = 0;
	ssize_t read;
	char **config_args;
	
	/*Read and execute the commands in the config file*/
	while ((read = getline(&temp_line, &len, file_pointer)) != -1) 
	{
		printf("? %s\n", temp_line);
		config_args = ksh_split_line(temp_line);
		ksh_execute(config_args);
	}
	if (temp_line)
	{
		free(temp_line);
	}
	printf("-----CONFIG SUCCESSFULLY EXECUTED-----\n");
}

int main(int argc, char **argv)
{
	
	/*load config files from .kapishrc*/
	init_config();
	
	/*Execution process: loop command - will interpret commands from the command line.*/
	ksh_loop();
	
	return EXIT_SUCCESS;
	
}