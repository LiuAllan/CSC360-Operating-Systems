#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv)
{
	while (1)
	{
		printf("Hello! This process is running. Press ENTER to repeat this message");
		getchar();
	}
}
