Allan Liu
V00806981
CSC360
Assignment 1

References:

https://brennan.io/2015/01/16/write-a-shell-in-c/
https://codereview.stackexchange.com/questions/67746/simple-shell-in-c
https://www.cs.swarthmore.edu/~newhall/unixhelp/howto_makefiles.html
https://stackoverflow.com/questions/35823864/detecting-ctrl-d-in-c

- No known bugs
- Have not experienced any memory leaks

*******************************************************************
HOW TO RUN kapish shell:

1. Copy the .kapishrc into your home directory
	- if you don't it will throw an error saying it can't find it and will continue to the shell prompt. No config will be executed
	
2. Type 'make' to use makefile 
	- this will compile kapish and compile test_process

3. ./kapish to run the shell

4. Running Processes
	- test_process just runs print statements in an infinite loop
	- Ctrl + C to close test_process while running on kapish
	- Running kapish on kapish will work

5. Closing the shell
	- Ctrl + D or type 'exit' in the prompt
	
6. Built-in commands all working as intended

