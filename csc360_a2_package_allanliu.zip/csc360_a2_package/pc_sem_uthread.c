/*
	Allan Liu
	V00806981
	CSC360 Assignment 2 - semaphores and uthread
*/

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "uthread.h"
#include "uthread_sem.h"

#define MAX_ITEMS 10
const int NUM_ITERATIONS = 200;
const int NUM_CONSUMERS  = 2;
const int NUM_PRODUCERS  = 2;

int histogram [MAX_ITEMS+1]; // histogram [i] == # of times list stored i items

int items = 0;

/*initialize*/
uthread_sem_t mutex_lock; //1
uthread_sem_t full; //10
uthread_sem_t empty; //0

void* producer (void* v) {
  for (int i=0; i<NUM_ITERATIONS; i++) {
	  uthread_sem_wait(full); // sem is available (0 >) - count from full (decrement and continue thread)
	  uthread_sem_wait(mutex_lock); //locks (decrement lock by 1)
	  items++;
	  histogram[items]++;
	  // check condition
	  assert(items <= MAX_ITEMS);
	  uthread_sem_signal(mutex_lock); //unlocks 
	  uthread_sem_signal(empty); // count from empty (increment by 1 each time)
  }
  return NULL;
}

void* consumer (void* v) {
  for (int i=0; i<NUM_ITERATIONS; i++) {
	  uthread_sem_wait(empty);
	  uthread_sem_wait(mutex_lock);
	  items--;
	  histogram[items]++;
	  // check condition
	  assert(items >= 0);
	  uthread_sem_signal(mutex_lock);
	  uthread_sem_signal(full);
  }
  return NULL;
}

int main (int argc, char** argv) {
  uthread_t t[4];

  uthread_init (4);
  mutex_lock = uthread_sem_create(1);
  empty = uthread_sem_create(0);
  full = uthread_sem_create(MAX_ITEMS);
  
  // TODO: Create Threads and Join
  t[0] = uthread_create(producer, NULL);
  t[1] = uthread_create(producer, NULL);
  t[2] = uthread_create(consumer, NULL);
  t[3] = uthread_create(consumer, NULL);

  for (int i = 0; i < 4; i++) 
  {
    uthread_join(t[i], NULL);
  }
  
  printf ("items value histogram:\n");
  int sum=0;
  for (int i = 0; i <= MAX_ITEMS; i++) {
    printf ("  items=%d, %d times\n", i, histogram [i]);
    sum += histogram [i];
  }
  assert (sum == sizeof (t) / sizeof (uthread_t) * NUM_ITERATIONS);
}