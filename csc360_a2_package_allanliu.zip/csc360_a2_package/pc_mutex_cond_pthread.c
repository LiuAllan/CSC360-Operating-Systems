/*
	Allan Liu
	V00806981
	CSC 360
	Assignment 2 - pthread mutex and condition variables
*/

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <pthread.h>

#define MAX_ITEMS 10
const int NUM_ITERATIONS = 200;
const int NUM_CONSUMERS  = 2;
const int NUM_PRODUCERS  = 2;

int producer_wait_count;     // # of times producer had to wait
int consumer_wait_count;     // # of times consumer had to wait
int histogram [MAX_ITEMS+1]; // histogram [i] == # of times list stored i items

int items = 0;

/*initialize mutex and condition variables*/
pthread_mutex_t mutex_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t full = PTHREAD_COND_INITIALIZER;
pthread_cond_t free_s = PTHREAD_COND_INITIALIZER;


void* producer (void* v) {
  for (int i=0; i<NUM_ITERATIONS; i++) {
    pthread_mutex_lock(&mutex_lock);
	/*exceed max number of items; wait for consumer to operate on items
	mutex is unlocked if conditon variable in consumer() is signaled*/
	
	/*if(items == MAX_ITEMS)*/
	while (items == MAX_ITEMS)
	{
		pthread_cond_wait(&full, &mutex_lock);
		producer_wait_count++;
	}
	/*produce items*/
	items++;
	histogram[items]++;
	
	pthread_cond_signal(&free_s);
	pthread_mutex_unlock(&mutex_lock);
  }
  return NULL;
}

void* consumer (void* v) {
  for (int i=0; i<NUM_ITERATIONS; i++) {
    pthread_mutex_lock(&mutex_lock);
	/*need to wait for producer to produce items*/
	while (items == 0)
	{
		pthread_cond_wait(&free_s, &mutex_lock);
		consumer_wait_count++;
	}
	/*consume items*/
	items--;
	histogram[items]++;
	
	pthread_cond_signal(&full);
	pthread_mutex_unlock(&mutex_lock);
  }
  return NULL;
}

int main (int argc, char** argv) {
  
  // TODO: Create Threads and Join
  /*store the threads*/
  pthread_t thread[NUM_CONSUMERS + NUM_PRODUCERS];
  int check1, check2, check3, check4;

  /*create threads*/
  if ((check1 = pthread_create(&thread[0], NULL, &producer, NULL)))
  {
	  printf("Thread creation failed: %d\n", check1);
  }
  if ((check2 = pthread_create(&thread[1], NULL, &producer, NULL)))
  {
	  printf("Thread creation failed: %d\n", check2);
  }
  if ((check3 = pthread_create(&thread[2], NULL, &consumer, NULL)))
  {
	  printf("Thread creation failed: %d\n", check3);
  }
  if ((check4 = pthread_create(&thread[3], NULL, &consumer, NULL)))
  {
	  printf("Thread creation failed: %d\n", check4);
  }

  /* join threads */
  for(int i =0;i < 4; i++)
  {
	  pthread_join(thread[i], NULL);
  }
  
  printf ("producer_wait_count=%d\nconsumer_wait_count=%d\n", producer_wait_count, consumer_wait_count);
  
  printf ("items value histogram:\n");
  int sum=0;
  for (int i = 0; i <= MAX_ITEMS; i++) {
    printf ("  items=%d, %d times\n", i, histogram [i]);
    sum += histogram [i];
  }
  /*check the changes to items is accurate*/
  assert (sum == sizeof (thread) / sizeof (pthread_t) * NUM_ITERATIONS);
  
  exit(EXIT_SUCCESS);
}