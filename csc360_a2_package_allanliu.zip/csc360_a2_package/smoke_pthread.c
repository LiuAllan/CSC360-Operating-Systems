/*
	Allan Liu
	V00806981
	CSC360 Assignment 2 - smokers problem pthread
*/

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>

#define NUM_ITERATIONS 1000

#ifdef VERBOSE
#define VERBOSE_PRINT(S, ...) printf (S, ##__VA_ARGS__);
#else
#define VERBOSE_PRINT(S, ...) ;
#endif

struct Agent {
  pthread_mutex_t mutex;
  pthread_cond_t  match;
  pthread_cond_t  paper;
  pthread_cond_t  tobacco;
  pthread_cond_t  smoke;
};

struct Agent* createAgent() {
  struct Agent* agent = malloc (sizeof (struct Agent));
  pthread_mutex_init(&agent->mutex, NULL);
  pthread_cond_init(&agent->match, NULL);
  pthread_cond_init(&agent->paper, NULL);
  pthread_cond_init(&agent->tobacco, NULL);
  pthread_cond_init(&agent->smoke, NULL);
  return agent;
}

pthread_cond_t match_paper;
pthread_cond_t paper_tobacco;
pthread_cond_t match_tobacco;


/*	resource flag to keep track of available resources
	increment = 1 resource*/
struct Resources
{
	int match;
	int paper;
	int tobacco;
};
struct Resources res = {0, 0, 0};


/**
 * You might find these declarations helpful.
 *   Note that Resource enum had values 1, 2 and 4 so you can combine resources;
 *   e.g., having a MATCH and PAPER is the value MATCH | PAPER == 1 | 2 == 3
 */
enum Resource            {    MATCH = 1, PAPER = 2,   TOBACCO = 4};
char* resource_name [] = {"", "match",   "paper", "", "tobacco"};

int signal_count [5];  // # of times resource signalled
int smoke_count  [5];  // # of times smoker with resource smoked

/**
 * This is the agent procedure.  It is complete and you shouldn't change it in
 * any material way.  You can re-write it if you like, but be sure that all it does
 * is choose 2 random reasources, signal their condition variables, and then wait
 * wait for a smoker to smoke.
 */
void* agent (void* av) {
  struct Agent* a = av;
  static const int choices[]         = {MATCH|PAPER, MATCH|TOBACCO, PAPER|TOBACCO};
  static const int matching_smoker[] = {TOBACCO,     PAPER,         MATCH};
  
  pthread_mutex_lock (&a->mutex);
    for (int i = 0; i < NUM_ITERATIONS; i++) {
      int r = random() % 3;
      signal_count [matching_smoker [r]] ++;
      int c = choices [r];
      if (c & MATCH) {
        pthread_cond_signal (&a->match);
      }
      if (c & PAPER) {
        pthread_cond_signal (&a->paper);
      }
      if (c & TOBACCO) {
        pthread_cond_signal (&a->tobacco);
      }
      pthread_cond_wait (&a->smoke, &a->mutex);
    }
  pthread_mutex_unlock (&a->mutex);
  return NULL;
}
/*decides who should smoke given the resources by the agent
	set the resource flags accordingly*/
void decider() 
{
	if(res.match && res.paper)
	{
		res.match = 0;
		res.paper = 0;
		pthread_cond_signal(&match_paper);
	} 
	else if(res.match && res.tobacco)
	{
		res.match = 0;
		res.tobacco = 0;
		pthread_cond_signal(&match_tobacco);
	} 
	else if(res.paper && res.tobacco) 
	{
		res.paper = 0;
		res.tobacco = 0;
		pthread_cond_signal(&paper_tobacco);
	} 
	return;
}
/*threads for the resources (producer)*/
void* match_handler (void* av) 
{
	struct Agent* v = av;
	pthread_mutex_lock(&v->mutex);
	for(;;)
	{
		pthread_cond_wait(&v->match, &v->mutex);
		res.match = 1;
		decider();
	}	
	pthread_mutex_unlock(&v->mutex);
}

void* paper_handler (void* av) 
{
	struct Agent* v = av;
	/*attempt to lock*/
	pthread_mutex_lock(&v->mutex);
	for(;;) 
	{
		pthread_cond_wait(&v->paper, &v->mutex);
		res.paper = 1;
		decider();
	}
	pthread_mutex_unlock(&v->mutex);
}

void* tobacco_handler (void* av) 
{
	struct Agent* v = av;
	pthread_mutex_lock(&v->mutex);
	/*wait for Agent ro give tobacco*/
	for(;;) 
	{
		pthread_cond_wait(&v->tobacco, &v->mutex);
		res.tobacco = 1;
		decider();
	}
	pthread_mutex_unlock(&v->mutex);
}
/*threads for smoking (consume)*/
void* smoke_match (void* av) 
{
	struct Agent* v = av;
	pthread_mutex_lock(&v->mutex);
	for(;;) 
	{
		pthread_cond_wait(&paper_tobacco, &v->mutex);
		pthread_cond_signal(&v->smoke);
		smoke_count [MATCH]++;
	}
	pthread_mutex_unlock(&v->mutex);
}

void* smoke_paper (void* av) 
{
	struct Agent* v = av;
	pthread_mutex_lock(&v->mutex);
	for(;;) 
	{
		pthread_cond_wait(&match_tobacco, &v->mutex);
		pthread_cond_signal(&v->smoke);
		smoke_count [PAPER]++;
	}
	pthread_mutex_unlock(&v->mutex);
}

void* smoke_tobacco (void* av) 
{
	struct Agent* v = av;
	pthread_mutex_lock(&v->mutex);
	for(;;) 
	{
		pthread_cond_wait(&match_paper, &v->mutex);
		pthread_cond_signal(&v->smoke);
		smoke_count [TOBACCO]++;
	}
	pthread_mutex_unlock(&v->mutex);
}

int main (int argc, char** argv) {

	/*pthreads*/
  pthread_t match;
  pthread_t paper;
  pthread_t tobacco;
  pthread_t match_handler_t;
  pthread_t paper_handler_t;
  pthread_t tobacco_handler_t;
  pthread_t agent_thread;
	
  struct Agent*  a = createAgent();
  
  /*initialize condition variables*/
  pthread_cond_init(&match_paper, NULL);
  pthread_cond_init(&match_tobacco, NULL);
  pthread_cond_init(&paper_tobacco, NULL);
  
  /*create threads*/
  pthread_create(&match, NULL, smoke_match, a);
  pthread_create(&paper, NULL, smoke_paper, a);
  pthread_create(&tobacco, NULL, smoke_tobacco, a);

  pthread_create(&match_handler_t, NULL, match_handler, a);
  pthread_create(&paper_handler_t, NULL, paper_handler, a);
  pthread_create(&tobacco_handler_t, NULL, tobacco_handler, a);

  pthread_create(&agent_thread, NULL, agent, a);

  pthread_join (agent_thread, NULL);
  
  assert (signal_count [MATCH]   == smoke_count [MATCH]);
  assert (signal_count [PAPER]   == smoke_count [PAPER]);
  assert (signal_count [TOBACCO] == smoke_count [TOBACCO]);
  assert (smoke_count [MATCH] + smoke_count [PAPER] + smoke_count [TOBACCO] == NUM_ITERATIONS);
  printf ("Smoke counts: %d matches, %d paper, %d tobacco\n",
          smoke_count [MATCH], smoke_count [PAPER], smoke_count [TOBACCO]);
}