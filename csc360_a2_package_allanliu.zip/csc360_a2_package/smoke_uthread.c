/*
	Allan Liu
	V00806981
	CSC360 Assignment 2 - smokers problem uthread
*/

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <fcntl.h>
#include <unistd.h>
#include "uthread.h"
#include "uthread_mutex_cond.h"

#define NUM_ITERATIONS 1000

#ifdef VERBOSE
#define VERBOSE_PRINT(S, ...) printf (S, ##__VA_ARGS__);
#else
#define VERBOSE_PRINT(S, ...) ;
#endif

struct Agent {
  uthread_mutex_t mutex;
  uthread_cond_t  match;
  uthread_cond_t  paper;
  uthread_cond_t  tobacco;
  uthread_cond_t  smoke;
};

struct Agent* createAgent() {
  struct Agent* agent = malloc (sizeof (struct Agent));
  agent->mutex   = uthread_mutex_create();
  agent->paper   = uthread_cond_create (agent->mutex);
  agent->match   = uthread_cond_create (agent->mutex);
  agent->tobacco = uthread_cond_create (agent->mutex);
  agent->smoke   = uthread_cond_create (agent->mutex);
  return agent;
}

//
// TODO
// You will probably need to add some procedures and struct etc.
//

struct decider
{
	struct Agent* agent;
	int match, paper, tobacco;
	uthread_cond_t paper_tobacco;
	uthread_cond_t match_tobacco;
	uthread_cond_t match_paper;
	uthread_cond_t smoke_it; //???
};

struct decider* create_decider(struct Agent* addr_of_a)
{
	struct decider* decide = malloc(sizeof(struct decider));
	decide->paper_tobacco = uthread_cond_create(addr_of_a->mutex);
	decide->match_tobacco = uthread_cond_create(addr_of_a->mutex);
	decide->match_paper = uthread_cond_create(addr_of_a->mutex);
	decide->smoke_it = uthread_cond_create(addr_of_a->mutex);
	decide->agent = addr_of_a;
	/*resource flags*/
	decide->match = 0;
	decide->paper = 0;
	decide->tobacco = 0;
	return decide;
}

/**
 * You might find these declarations helpful.
 *   Note that Resource enum had values 1, 2 and 4 so you can combine resources;
 *   e.g., having a MATCH and PAPER is the value MATCH | PAPER == 1 | 2 == 3
 */
enum Resource            {    MATCH = 1, PAPER = 2,   TOBACCO = 4};
char* resource_name [] = {"", "match",   "paper", "", "tobacco"};

int signal_count [5];  // # of times resource signalled
int smoke_count  [5];  // # of times smoker with resource smoked

/**
 * This is the agent procedure.  It is complete and you shouldn't change it in
 * any material way.  You can re-write it if you like, but be sure that all it does
 * is choose 2 random reasources, signal their condition variables, and then wait
 * wait for a smoker to smoke.
 */
void* agent (void* av) {
  struct Agent* a = av;
  static const int choices[]         = {MATCH|PAPER, MATCH|TOBACCO, PAPER|TOBACCO};
  static const int matching_smoker[] = {TOBACCO,     PAPER,         MATCH};
  
  uthread_mutex_lock (a->mutex);
    for (int i = 0; i < NUM_ITERATIONS; i++) {
      int r = random() % 3;
      signal_count [matching_smoker [r]] ++;
      int c = choices [r];
      if (c & MATCH) {
        VERBOSE_PRINT ("match available\n");
        uthread_cond_signal (a->match);
      }
      if (c & PAPER) {
        VERBOSE_PRINT ("paper available\n");
        uthread_cond_signal (a->paper);
      }
      if (c & TOBACCO) {
        VERBOSE_PRINT ("tobacco available\n");
        uthread_cond_signal (a->tobacco);
      }
      VERBOSE_PRINT ("agent is waiting for smoker to smoke\n");
      uthread_cond_wait (a->smoke);
    }
  uthread_mutex_unlock (a->mutex);
  return NULL;
}

/*decides who should smoke given the resources by the agent*/
void decide_which (struct decider* d, enum Resource r, uthread_cond_t c, int* free)
{
	uthread_mutex_lock(d->agent->mutex);
	for(;;)
	{
		uthread_cond_wait(c);
		*free = 1;
		if (d->match && d->tobacco)
		{
			d->match = 0;
            d->tobacco = 0;
			//printf("%d\n", PAPER);
            uthread_cond_signal(d->match_tobacco);
            uthread_cond_wait(d->smoke_it);
            uthread_cond_signal(d->agent->smoke);
		}
		else if (d->match && d->paper)
		{
			d->match = 0;
            d->paper = 0;
			uthread_cond_signal(d->match_paper);
            uthread_cond_wait(d->smoke_it);
            uthread_cond_signal(d->agent->smoke);
		}
		else if (d->tobacco && d->paper)
		{
			d->tobacco = 0;
            d->paper = 0;
			uthread_cond_signal(d->paper_tobacco);
            uthread_cond_wait(d->smoke_it);
            uthread_cond_signal(d->agent->smoke);
		}
	}
	uthread_mutex_unlock(d->agent->mutex);
}

/*controller for smoking*/
void smoke (struct decider* d, enum Resource r, uthread_cond_t c)
{
	uthread_mutex_lock(d->agent->mutex);
	for(;;)
	{
		uthread_cond_wait(c);
		smoke_count[r]++;
		//printf("%d\n", r);

		uthread_cond_signal(d->smoke_it);
	}
	uthread_mutex_unlock(d->agent->mutex);
}

/*threads for the resources (producer)*/
void* match_handler (void* temp)
{
	struct decider* d = temp;
    decide_which(d, MATCH, d->agent->match, &d->match);
	signal_count[MATCH]++;
}

void* paper_handler (void* temp)
{
	struct decider* d = temp;
    decide_which(d, PAPER, d->agent->paper, &d->paper);
	signal_count[PAPER]++;
}

void* tobacco_handler (void* temp)
{
	struct decider* d = temp;
    decide_which(d, TOBACCO, d->agent->tobacco, &d->tobacco);
	signal_count[TOBACCO]++;
}

/*threads for smoking (consume)*/

void* smoke_match (void* temp){
    struct decider* d = temp;
    smoke (d, MATCH, d->paper_tobacco);
}

void* smoke_paper (void* temp){
    struct decider* d = temp;
    smoke (d, PAPER, d->match_tobacco);
}

void* smoke_tobacco (void* temp){
    struct decider* d = temp;
    smoke (d, TOBACCO, d->match_paper);
}

int main (int argc, char** argv) {
  uthread_init (7);
  struct Agent*  a = createAgent();
  /*create a decider with a as the agent
	decider decides who gets the smoke*/
  struct decider* d = create_decider(a);
  
  uthread_create(match_handler, d);
  uthread_create(paper_handler, d);
  uthread_create(tobacco_handler, d);
  
  uthread_create(smoke_match, d);
  uthread_create(smoke_paper, d);
  uthread_create(smoke_tobacco, d);
  
  uthread_join (uthread_create (agent, a), 0);
  //printf("%d\n", signal_count[MATCH]);
  //printf("%d\n", smoke_count[MATCH]);
  assert (signal_count [MATCH]   == smoke_count [MATCH]);
  assert (signal_count [PAPER]   == smoke_count [PAPER]);
  assert (signal_count [TOBACCO] == smoke_count [TOBACCO]);
  assert (smoke_count [MATCH] + smoke_count [PAPER] + smoke_count [TOBACCO] == NUM_ITERATIONS);
  printf ("Smoke counts: %d matches, %d paper, %d tobacco\n",
          smoke_count [MATCH], smoke_count [PAPER], smoke_count [TOBACCO]);
}