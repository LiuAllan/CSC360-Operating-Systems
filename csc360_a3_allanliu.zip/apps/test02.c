#include "../io/File.c"
//#include "File.h"

/*
test02 tests read and writing to a file in the root directory.
Needs to run test01 before running test02.
*/

int main(void)
{
	  initLLFS();

	  block_read(1, free_blocks);
	  block_read(2, imap);
	  block_read(3, current_inode);
	  block_read(4, current_directory);
	  
	  current_directory_number = 4;
	  
	  char t2[] = "test_file";

	  puts("Listing all files in root directory");
	  list_direct();
	  printf("\n");

	  //write file
	  write_file(t2);
	  if(!flag)
	  printf("Input written to file: %s \n\n", t2);

	  //read file
	  read_file(t2);
	  if(!flag)
	  printf("End of file: %s\n", t2);

	  flag = 0;
		
	  return 0;
}
