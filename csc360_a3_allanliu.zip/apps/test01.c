#include "../io/File.c"
//#include "File.h"

/*
This program tests simple functionality using File.c such as creating directories and files.

1. Make and format the disk by calling initLLFS(). It does not create a duplicate or overwrite existing disks.

2. Make a directory in root. Gets 2 free blocks, initializes the first free block for an inode, initializes second free block to be directory, make the new inode point to the new directory, and add the new inode to the current directory.

3. Make a file for read and write. Process is the same for making a directory except a directory is not initialized.

4. List everything in the current root directory.

5. Change directory to the newly created one and make a sub-directory and a file.
*/
int main(void)
{
	//make disk
	  printf("Making and Formatting /disk/vdisk\n");
	  initLLFS();
	  printf("vdisk successfully created\n\n");
	  
	  block_read(1, free_blocks);
	  block_read(2, imap);
	  block_read(3, current_inode);
	  block_read(4, current_directory);
	  
	  current_directory_number = 4;

	  char t1[] = "test_dir";
	  char t2[] = "test_file";
	  char t3[] = "test_dir2";
	  char t4[] = "test_file2";
	  
	//make a directory
	  printf("Making directory 'test_dir' in root of vdisk\n");
      int free_b1, free_b2;
      free_b1 = get_free_block(); //free blocks
      free_b2 = get_free_block();
      char c1 = init_imap(free_b1);//c1 has the new inode number
      char c2 = 1;
      init_inode(free_b1, c2); //create first block an inode
      init_direc(c1, t1, free_b2);
      add_data_to_inode(free_b1, free_b2);
      add_inode_to_current_direc(c1, t1);
      printf("Directory %s successfully created\n\n", t1);
	
	//make a file
	  printf("Making file 'test_file' in root of vdisk\n");
      int free_b3, free_b4;
      free_b3 = get_free_block();
      free_b4 = get_free_block();
      char c3 = init_imap(free_b3);
      char c4 = 2;
      init_inode(free_b3, c4);
      add_data_to_inode(free_b3, free_b4);
      add_inode_to_current_direc(c3, t2);
      printf("File %s successfully created\n\n", t2);
	
	//list files
      puts("Listing all files in root directory");
      list_direct();
	  printf("\n");
	  
	  cd(t1);
	
	//make sub-directory
	  printf("Making sub-directory 'test_dir2' in 'test_dir'\n");
      int free_b5, free_b6;
      free_b5 = get_free_block();
      free_b6 = get_free_block();     //got free blocks
      char c5 = init_imap(free_b1);  //c1 is the new inode number
      char c6 = 1;
      init_inode(free_b5, c6);            //inode for file in block fn1
      init_direc(c5, t3, free_b6);    //directory initalized with name t2, inode number c1 in block free_b2
      add_data_to_inode(free_b5, free_b6);
      add_inode_to_current_direc(c5, t3);
      printf("Directory %s successfully created\n\n", t3);

	  //make file in sub-directory
	  printf("Making file 'test_file2' in directory 'test_dir'\n");
      int free_b7, free_b8;
      free_b7 = get_free_block();
      free_b8 = get_free_block();     //got free blocks
      char c7 = init_imap(free_b7);  //c1 is the new inode number
      char c8 = 2;
      init_inode(free_b7, c8);
      add_data_to_inode(free_b7, free_b8);
      add_inode_to_current_direc(c7, t4);
      printf("File %s successfully created\n\n", t4);
	
      puts("Listing all files in 'test_dir' directory");
      list_direct();
	  
	  
	  return 0;
}