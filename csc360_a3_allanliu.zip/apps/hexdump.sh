#!/bin/bash
# bash script that output hexdump of vdisk

make
./test01
hexdump -C ../disk/vdisk > hexdump_vdisk_test01.txt

./test02
hexdump -C ../disk/vdisk > hexdump_vdisk_test02.txt

./test03
hexdump -C ../disk/vdisk > hexdump_vdisk_test03.txt

