#include "../io/File.c"
//#include "File.h"

/*
This program tests reading, writing, and deltion of files and directories.
test03 requires at least test01 to be run first before testing. test02 is optional.
*/

int main(void)
{
	  initLLFS();

	  block_read(1, free_blocks);
	  block_read(2, imap);
	  block_read(3, current_inode);
	  block_read(4, current_directory);
	  
	  current_directory_number = 4;
	  
	  char t1[] = "test_dir";
	  char t3[] = "test_dir2";
	  char t4[] = "test_file2";
	  
	  cd(t1);

	  puts("Listing all files in 'test_dir' directory");
	  list_direct();
	  printf("\n");

	  //write file
	  write_file(t4);
	  if(!flag)
	  printf("Input written to file: %s \n\n", t4);

	  //read file
	  read_file(t4);
	  if(!flag)
	  printf("End of file: %s\n\n", t4);

	  //deletion
	  delete_file(t4);
	  if(!flag)
	  printf("File %s deleted\n\n", t4);

	  delete_file(t3);
	  if(!flag)
	  printf("Directory %s deleted\n\n", t3);

	  puts("Listing all files in 'test_dir' directory");
	  list_direct();
	  printf("\n");

	  flag = 0;
		
	  return 0;
}