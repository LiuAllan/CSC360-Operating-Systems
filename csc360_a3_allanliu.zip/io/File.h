#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>

//for making /disk
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define BLOCK_SIZE 512
#define DISK_BLOCKS 4096

#define BUFFERSIZE 32

#ifndef _FILE_H_
#define _FILE_H_

int open_file;   
static char x, y; //for binarize()
char *t1, *t2;  //strings where user input is stored after being tokenized
char input[BUFFERSIZE]; //char array where user input is stored

int current_directory_number;           //the block number for the current directory
char current_file_inode[BLOCK_SIZE];     //storage for inode of current file
int current_file_number;

// all read/write block size of 512 bytes
char current_block[BLOCK_SIZE]; 	//store current block
char current_inode[BLOCK_SIZE];     //store inode of current file
char current_directory[BLOCK_SIZE]; //store current directory file
char free_blocks[BLOCK_SIZE];       //store free block vector
char imap[BLOCK_SIZE];             //store imap, which is stored in block 2

int flag = 0;

void make_vdisk(char *file_name);
void open_vdisk(char *file_name);
void block_write(int block, char *buffer);
void block_read(int block, char *buffer);
void binarize(int n);
int debinarize(char a, char b);
int initLLFS(void);
int get_free_block();
char init_imap(int n); //block number n
void init_inode(int inode_block, char type_of_file);
void init_direc(char fi, char* t2, int block_num);
void add_data_to_inode(int _inode, int _block);
void add_inode_to_current_direc(char new_direct, char* t2);
void list_direct(void);
char search_current_directory(char *str);
int find_block_number(char a);
void cd(char* _str);
char* getString(int* n);
void write_file(char* file_name);
void read_file(char* file_name);
void clear_block(int block_n);
void clear_block_number(char a);
void clear_directory(char* directory_str);
void clear_block_vector(int n);
void delete_file(char* file_name);
#endif