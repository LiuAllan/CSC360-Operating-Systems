/*
Allan Liu
V00806981
CSC360 Assignment 3
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>
//#include "File.h"

//for making /disk
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define BLOCK_SIZE 512
#define DISK_BLOCKS 4096
#define BUFFERSIZE 32

int open_file;   
static char x, y; //for bin() change to binary
char *t1, *t2;  //strings where user input is stored after being tokenized
char input[32]; //char array where user input is stored

int current_directory_number;           //the block number for the current directory
char current_file_inode[BLOCK_SIZE];     //storage for inode of current file
int current_file_number;

// all read/write block size of 512 bytes
char current_block[BLOCK_SIZE]; 	//store current block
char current_inode[BLOCK_SIZE];     //store inode of current file
char current_directory[BLOCK_SIZE]; //store current directory file
char free_blocks[BLOCK_SIZE];       //store free block vector
char imap[BLOCK_SIZE];             //store imap, which is stored in block 2

int flag = 0;

int initLLFS(void);
void make_vdisk(char *file_name);
void open_vdisk(char *file_name);
void block_write(int block, char *buffer);
void block_read(int block, char *buffer);
void bin(int n);
int debin(char a, char b);
int get_free_block();
char init_imap(int n); //block number n
void init_inode(int inode_block, char type_of_file);
void init_direc(char fi, char* t2, int block_num);
void add_data_to_inode(int _inode, int _block);
void add_inode_to_current_direc(char new_direct, char* t2);
void list_direct(void);
char search_current_directory(char *str);
int find_block_number(char a);
void cd(char* user_string);
char* getString(int* n);
void write_file(char* file_name);
void read_file(char* file_name);
void clear_block(int block_n);
void clear_block_number(char a);
void clear_directory(char* directory_str);
void clear_block_vector(int n);
void delete_file(char* file_name);

//**********************************************************************

//initialize the vdisk by first checking if the disk exists, then make and open the disk for formatting
int initLLFS(void)
{
	//http://pubs.opengroup.org/onlinepubs/009695299/functions/access.html
	if(!access("../disk/vdisk", F_OK))
	{
		open_vdisk("../disk/vdisk");
		return 0;
	}

	char a, b, c;
	int i, j, k;
	make_vdisk("../disk/vdisk");
	open_vdisk("../disk/vdisk");
	  
	//BLOCK 0
	i = 1, j = DISK_BLOCKS, k = 54; 
	char test_buff[BLOCK_SIZE];
	block_read(0, test_buff); //read in a block
	memcpy(test_buff, &i, 4); //https://www.tutorialspoint.com/c_standard_library/c_function_memcpy.htm
	memcpy(&test_buff[4], &j, 4);
	memcpy(&test_buff[8], &k, 4);
	test_buff[12] = '\0'; //null is a 0 in hexdump
	block_write(0, test_buff);
	  
	//BLOCK 1
	c = 255;
	block_read(1, test_buff);
	memset(test_buff, c, BLOCK_SIZE);
	c = 0;
	test_buff[0] = c;
	c = 127;
	test_buff[1] = c;
	block_write(1, test_buff);

	//BLOCK 2 - imap to keep track of inodes (inode map)
	block_read(2, test_buff);
	a = 1, b = 1;
	i = 3;
	memcpy(test_buff, &a, 1);
	memcpy(&test_buff[1], &a, 1);
	memcpy(&test_buff[2], &b, 1);
	memcpy(&test_buff[3], &b, 1);
	memcpy(&test_buff[4], &i, 4);
	int test;
	memcpy(&test, &test_buff[4], 4);
	
	//a = available, b = inode number, i = block number, j = byte number
	j = 8;
	for(a = 2, b = 2, i = 0; b <= 54; b++)
	{
		memcpy(&test_buff[j++], &a, 1);
		memcpy(&test_buff[j++], &a, 1);
		memcpy(&test_buff[j++], &b, 1);
		memcpy(&test_buff[j++], &b, 1);
		memcpy(&test_buff[j++], &i, 4);
		j += 3;
	}
	j -= 3;
	test_buff[j] = '\0';
	block_write(2, test_buff);

	//BLOCK 3
	block_read(3, test_buff);
	i = BLOCK_SIZE;
	a = 1; //directory
	bin(4);
	memcpy(test_buff, &i, 4);
	memcpy(&test_buff[4], &a, 1);
	j = 5;
	a = 0;
	for(i = 0; i < 3; i++)
	{
		memcpy(&test_buff[j++], &a, 1);
	}
	memcpy(&test_buff[j++], &y, 1);
	memcpy(&test_buff[j++], &x, 1);
	for(i = 0; i < 11; i++)
	{
		memcpy(&test_buff[j++], &a, 1);
		memcpy(&test_buff[j++], &a, 1);
	}
	test_buff[j] = '\0';
	block_write(3, test_buff);

	//BLOCK 4 and onwards
	block_read(4, test_buff);
	a = 1;
	char mystr[31] = "/";
	fflush(stdout);
	memcpy(test_buff, &a, 1);
	strcpy(&test_buff[1], mystr);
	memcpy(&test_buff[32], &a, 1);
	strcpy(&test_buff[33], mystr);
	for(a = 0, i = 1, j = 64; i < 14; i++)
	{
		memcpy(&test_buff[j], &a, 1);
		j += 32;
	}
	block_write(4, test_buff);
	return 0;
	
	//don't have any indirection
}

void make_vdisk(char *file_name)
{
	struct stat st = {0};

	if (stat("../disk", &st) == -1)  //check if /disk exists. if not create
	{
		mkdir("../disk", 0700);
	}
	
	int i;
	char buff[BLOCK_SIZE];
	if ((open_file = open(file_name, O_WRONLY | O_CREAT | O_TRUNC, 0644)) < 0) 
	{
		puts("ERROR in make_vdisk");
		return;
	}
	memset(buff, 0, BLOCK_SIZE);
	for (i = 0; i < DISK_BLOCKS; ++i)
	{
		if(write(open_file, buff, BLOCK_SIZE) < 0)
		{
			puts("ERROR in make_vdisk");
			return;
		}
	}
	close(open_file);
}

void open_vdisk(char *file_name)
{
	//http://man7.org/linux/man-pages/man2/open.2.html
	if ((open_file = open(file_name, O_RDWR, 0644)) < 0) //argument flags open for read and write
	{
		puts("ERROR in open_vdisk");
	}
}

void block_write(int block, char *buffer)
{
	if (block < 0 || block >= DISK_BLOCKS) //less than or greater than the total amount of blocks we have on disk
	{
		//https://www.tutorialspoint.com/c_standard_library/c_function_puts.htm
		puts("block number out of bounds in block_write");
		return;
	}
	if (lseek(open_file, block * BLOCK_SIZE, SEEK_SET) < 0) //lseek moves the read/write file offset
	{
		puts("ERROR in block_write");
		return;
	}
	if (write(open_file, buffer, BLOCK_SIZE) < 0) 
	{
		puts("ERROR in block_write");
	}
}

void block_read(int block, char *buffer)
{
	if (block < 0 || block >= DISK_BLOCKS) 
	{
		puts("block number out of bounds in block_read");
		return;
	}
	if (lseek(open_file, block * BLOCK_SIZE, SEEK_SET) < 0) 
	{
		puts("ERROR in block_write");
		return;
	}
	if(read(open_file, buffer, BLOCK_SIZE) < 0) 
	{
		puts("ERROR in block_read");
		return;
	}
}

void bin(int n)
{
	x = y = 255;
	x = x&n;
	y = y&(n>>8);
}

//Changes a two char number into a four byte integer
int debin(char a, char b)
{
	int n = 0;
	n = (n|a);
	n = ((n<<8)|b);
	return n;
}

int get_free_block()
{
	char a, c = 128;
	int i, j;
	for(i = 1; i < BLOCK_SIZE; i++)
	{
		memcpy(&a, &free_blocks[i], 1);
		for(j = 0; j < 8; j++)
		{
			if((c&a) == (char)128)
			{
				free_blocks[i] = ((~((char)128))&a);
				block_write(1, free_blocks);
				return (i*8)+j;
			}
			if(((c>>1)&a) == (char)64)
			{
				free_blocks[i] = ((~((char)64))&a);
				block_write(1, free_blocks);
				return (i*8)+j+1;
			}
			if(((c>>2)&a) == (char)32)
			{
				free_blocks[i] = ((~((char)32))&a);
				block_write(1, free_blocks);
				return (i*8)+j+2;
			}
			if(((c>>3)&a) == (char)16)
			{
				free_blocks[i] = ((~((char)16))&a);
				block_write(1, free_blocks);
				return (i*8)+j+3;
			}
			if(((c>>4)&a) == (char)8)
			{
				free_blocks[i] = ((~((char)8))&a);
				block_write(1, free_blocks);
				return (i*8)+j+4;
			}
			if(((c>>5)&a) == (char)4)
			{
				free_blocks[i] = ((~((char)4))&a);
				block_write(1, free_blocks);
				return (i*8)+j+5;
			}
			if(((c>>6)&a) == (char)2)
			{
				free_blocks[i] = ((~((char)2))&a);
				block_write(1, free_blocks);
				return (i*8)+j+6;
			}
			if(((c>>7)&a) == (char)1)
			{
				free_blocks[i] = ((~((char)1))&a);
				block_write(1, free_blocks);
				return (i*8)+j+7;
			}
		}
	}
	return 0;
}

//Puts block number n in first free inode position. Returns the inode number allocated. 
char init_imap(int n) //block number n
{
	if(n == 0)
	{
		puts("no more block space"); //output to stdout
		exit(1);
	}
	
	int i, j = 8;
	char a; //inode number
	for(i = 2; i <= 54; i++)
	{
		memcpy(&a, &imap[j], 1); //copies the inode number into temporary char to check block
		if(a == 2) //in block 2
		{
			a = 1; //change to block1 (free block vector)
			memcpy(&imap[j++], &a, 1);
			memcpy(&imap[j++], &a, 1);
			memcpy(&a, &imap[j], 1);
			j += 2;
			memcpy(&imap[j], &n, 4); //putting the block number n in first free inode position.
			block_write(2, imap); // make sure writting to block has throws no errors
			return a;
		}
		j += 8;
	}
}

//make an inode ready for a file or directory
void init_inode(int inode_block, char type_of_file)
{
	int i, j;
	char a = 0;
	char temp_buffer[BLOCK_SIZE] = "";
	i = BLOCK_SIZE; // i = 512 bytes
	memcpy(temp_buffer, &i, 4);
	memcpy(&temp_buffer[4], &type_of_file, 1);
	
	for(i = 0, j = 5; i < 3; i++)
	{
		memcpy(&temp_buffer[j++], &a, 1); //copy 0 into test buffer
	}
	
	for(i = 0; i < 12; i++)
	{
		memcpy(&temp_buffer[j++], &a, 1);
		memcpy(&temp_buffer[j++], &a, 1);
	}
	temp_buffer[j] = '\0';
	block_write(inode_block, temp_buffer);
}

//initializes a directory
void init_direc(char fi, char* t2, int block_num)
{
	int i, j;
	char test_buff[BLOCK_SIZE] = "";
	char a;
	char mystr[31];
	strcpy(mystr, t2);
	memcpy(test_buff, &fi, 1);
	strcpy(&test_buff[1], mystr);
	memcpy(&test_buff[32], current_directory, 1);
	strcpy(&test_buff[33], &current_directory[1]);
	for(a = 0, i = 1, j = 64; i < 14; i++)
	{
		memcpy(&test_buff[j], &a, 1);
		j += 32;
	}
	block_write(block_num, test_buff);
}

//puts data in first free block of inode
void add_data_to_inode(int _inode, int _block)
{
	char temp_str[BLOCK_SIZE] = ""; //temp str of 512 bytes block
	block_read(_inode, temp_str);
	int i, j;
	for(i = 0, j = 8; i < 12; i++)
	{
		if(temp_str[j] == 0 && temp_str[j+1] == 0)
		{
			bin(_block);
			temp_str[j] = y;
			temp_str[j+1] = x;
			block_write(_inode, temp_str);
			return;
		}
		j += 2;
	}
	puts("inode has not enough room");
	fflush(stdout);
	exit(1);
}

// add the inode number of new directory then change the name of t2 to the current directory
void add_inode_to_current_direc(char new_direct, char* t2)
{
	int i, j;
	for(i = 2, j = 64; i < 16; i++)
	{
		if(current_directory[j] == (char)0)
		{
			memcpy(&current_directory[j++], &new_direct, 1); //copies the new directory to the list of current directories
			memcpy(&current_directory[j++], t2, 31); //name t2 to the current directory
			break;
		}
		j += 32;
	}
	block_write(current_directory_number, current_directory);
}

//list everything in the current directory
void list_direct(void)
{
	int i, j;
	char my_string[32];
	for(i = 1, j = 64; i < 14; i++)
	{
		//https://stackoverflow.com/questions/7578632/what-is-the-difference-between-char0-and-0-in-c
		
		// characters are numeric values in C. current_directory is a char, so need to typecast 0 a char
		// if(current_directory[j] == ((char)0))
		if(current_directory[j] == (0))
		{
			j += 32;
			continue;
		}
		printf("%d.  %s\n", i, &current_directory[j+1]);
		fflush(stdout); //make sure output is flushed out from buffer
		j += 32;
	}
}


//search the directory currently in for input string
//returns "a" = inode number for the string
char search_current_directory(char *str)
{
	int i, j;
	char a; //inode number
	for(i = 1, j = 1; i < 16; i++) //iterate through the list of current directory
	{
		if(strcmp(&current_directory[j], str) == 0) //string matches the char of current directory
		{
			j -= 1;
			memcpy(&a, &current_directory[j], 1);
			return a; //return the inode of the file/directory
		}
		j += 32;
	}
	  return 0; //not found
}

//find the block number of an inode
int find_block_number(char a)
{
	int i;
	int j = 3;
	int k;
	char b;
	for(i = 1; i <= 54; i++)
	{
		memcpy(&b, &imap[j], 1);
		if(a == b)
		{
			j++;
			memcpy(&k, &imap[j], 4);
			return k;
		}
		j += 8;
	}
	  return -1;
}

//change the directory to directory with name user_string
void cd(char* user_string)
{
	char inode_number, temp_inode_number;
	temp_inode_number = search_current_directory(user_string);
	if(temp_inode_number == 0)
	{
		puts("Error: No such directory!");
		fflush(stdout);
		flag = 1;
		return;
	}
	char hel[BLOCK_SIZE];
	int inode_block_number, temp_inode_block_number = find_block_number(temp_inode_number);
	block_read(temp_inode_block_number, hel);
	if(hel[4] != 1)
	{
		puts("Error: This is not a directory");
		fflush(stdout);
		flag = 1;
		return;
	}
	printf("Changing to directory: %s\n", user_string);
	inode_number = temp_inode_number;
	inode_block_number = temp_inode_block_number;
	fflush(stdout);
	block_read(inode_block_number, current_inode);
	char c2, c3;
	memcpy(&c2, &current_inode[8], 1);
	memcpy(&c3, &current_inode[9], 1);
	int b;
	b = debin(c2, c3);
	current_directory_number = b;
	block_read(current_directory_number, current_directory);
}

//get a string for the file input
char* getString(int* n)
{
	int i, size = 5;
	char* str;
	while((str = (char*)malloc(size)) == NULL);
	char c, *temp = str;
	c = getchar();
	i = 0;
	while(c != '\n' && str != NULL && *n < (BLOCK_SIZE-1))
	{
		*n += 1;
		str[i++] = c;
		c = getchar();
		if(i == size)
		{
		  while((str = (char*)realloc(str, (size += i))) == NULL);
		}
	}
	str[i] = '\0';
	return str;
}

//writing to a file that has been already created
void write_file(char* file_name)
{
	char inode_number, temp_inode_number;
	temp_inode_number = search_current_directory(file_name);
	if(temp_inode_number == 0)
	{
		puts("Error: Cannot find this file");
		flag = 1;
		fflush(stdout);
		return;
	}
	char hel[BLOCK_SIZE];
	int inode_block_number, temp_inode_block_number = find_block_number(temp_inode_number);
	block_read(temp_inode_block_number, hel);
	if(hel[4] != 2)
	{
		puts("Error: This is not a file");
		fflush(stdout);
		flag = 1;
		return;
	}
	printf("Opening file '%s'. Please input string:\n", file_name);
	fflush(stdout);
	inode_block_number = temp_inode_block_number;
	inode_number = temp_inode_number;
	block_read(inode_block_number, current_file_inode);
	char c2, c3;
	memcpy(&c2, &current_file_inode[8], 1);
	memcpy(&c3, &current_file_inode[9], 1);
	int b, j;
	b = debin(c2, c3);
	current_file_number = b;
	
	for(b = 0, j = 10; b < 11; b++, j += 2)
	{
		current_file_inode[j] = 0;
		current_file_inode[j+1] = 0;
	}
	
	block_write(inode_block_number, current_file_inode);
	b = 0;
	char *str_pointer;
	
	while(b == 0)
	{
		str_pointer = getString(&b);
		strcpy(current_block, str_pointer);
		block_write(current_file_number, current_block);
		fflush(stdout);
		if(b == (BLOCK_SIZE-1))
		{
			b = 0;
		}
		free(str_pointer);
		if(b == 0)
		{
			current_file_number = get_free_block();
			add_data_to_inode(inode_block_number, current_file_number);
		}
	}
}

//read or open a file that has been written
void read_file(char* file_name)
{
	char inode_number;
	char temp_inode_number;
	
	temp_inode_number = search_current_directory(file_name);
	
	if(temp_inode_number == 0)
	{
		puts("Error: Cannot find this file");
		flag = 1;
		fflush(stdout);
		return;
	}
	
	char hel[BLOCK_SIZE];
	int inode_block_number;
	int temp_inode_block_number = find_block_number(temp_inode_number);
	
	block_read(temp_inode_block_number, hel);
	
	if(hel[4] != 2)
	{
		puts("Error: This is not a file");
		fflush(stdout);
		flag = 1;
		return;
	}
	
	printf("Reading file: %s\n", file_name);
	fflush(stdout);
	
	inode_number = temp_inode_number;
	inode_block_number = temp_inode_block_number;
	block_read(inode_block_number, current_file_inode);
	
	char c2, c3;
	memcpy(&c2, &current_file_inode[8], 1);
	memcpy(&c3, &current_file_inode[9], 1);
	
	int b;
	int j = 10;
	b = debin(c2, c3);
	current_file_number = b;
	char temp_string[BLOCK_SIZE];
	
	while(current_file_number != 0)
	{
		block_read(current_file_number, temp_string);
		printf("%s", temp_string);
		fflush(stdout);
		memcpy(&c2, &current_file_inode[j], 1);
		memcpy(&c3, &current_file_inode[j+1], 1);
		current_file_number = debin(c2, c3);
		j += 2;
	}
	puts("");
	fflush(stdout);
}

//clears block from memory according to block number
void clear_block(int block_n)
{
	char clearing_str[BLOCK_SIZE];
	int i;
	for(i = 0; i < BLOCK_SIZE; i++)
	{
		clearing_str[i] = '\0';
	}
	block_write(block_n, clearing_str);
}

//garbage collection, clears the inode number of unused from the imap (imap)
void clear_block_number(char a)
{
	int i, j = 3;
	char b;
	for(i = 1; i <= 54; i++)
	{
		memcpy(&b, &imap[j], 1);
		if(a == b)
		{
			j++;
			memset(&imap[j], 0, 4); //copies 0 to the first 4 characters of inode list
			memset(&imap[j-4], 2, 2);
		}
		j += 8;
	}
}

//clears the directory of the file
void clear_directory(char* directory_str)
{
	int i, j;
	//iterate through the directory and compare of the to-be deleted directory
	for(i = 1, j = 1; i < 16; i++)
	{
		if(strcmp(&current_directory[j], directory_str) == 0)
		{
			memset(&current_directory[j], 0, 31); //set the directory to 0
			current_directory[j-1] = 0;
			return;
		}
		j += 32;
	}
}

//clears the block vector of block n to be available
void clear_block_vector(int n)
{
	int k = n;
	k = k/8;
	n = n%8;
	char c = free_blocks[k];
	
	//check all the blocks and clear them
	if(n == 0)
	{
		free_blocks[k] = (((char)127)&c);
	}
	if(n == 1)
	{
		free_blocks[k] = (((char)191)&c);
	}
	if(n == 2)
	{
		free_blocks[k] = (((char)223)&c);
	}
	if(n == 3)
	{
		free_blocks[k] = (((char)239)&c);
	}
	if(n == 4)
	{
		free_blocks[k] = (((char)247)&c);
	}
	if(n == 5)
	{
		free_blocks[k] = (((char)251)&c);
	}
	if(n == 6)
	{
		free_blocks[k] = (((char)253)&c);
	}
	if(n == 7)
	{
		free_blocks[k] = (((char)254)&c);
	}
}

//deletes files from
void delete_file(char* file_name)
{
	if(strcmp(file_name, "/") == 0)
	{
		puts("Error: Cannot delete root directory");
		return;
	}
	char inode_number;
	inode_number = search_current_directory(file_name);
	
	if(inode_number == 0)
	{
		puts("Error: File does not exist");
		flag = 1;
		fflush(stdout);
		return;
	}
	printf("Deleting file: %s\n", file_name);
	fflush(stdout);
	
	int inode_block_number = find_block_number(inode_number);
	block_read(inode_block_number, current_file_inode);
	
	char c2, c3;
	int b;
	
	memcpy(&c2, &current_file_inode[8], 1);
	memcpy(&c3, &current_file_inode[9], 1);
	
	b = debin(c2, c3);
	int j = 10;
	while(b != 0)
	{
		clear_block(b);
		clear_block_vector(b);
		memcpy(&c2, &current_file_inode[j], 1);
		memcpy(&c3, &current_file_inode[j+1], 1);
		b = debin(c2, c3);
		j += 2;
	}
	clear_block(inode_block_number); // clear block from memory
	clear_block_number(inode_number); //clear from inode map
	clear_directory(file_name);
	clear_block_vector(inode_block_number);
	
	block_write(2, imap); //write block 2 to imap
	block_write(1, free_blocks); //write block 1 to free blocks
	block_write(current_directory_number, current_directory);
}
